package com.example.dietapp.ui;

public class constant {

 //   public static String url = "http://192.168.7.147:81/Staff/sumayya/DIETAPP/";
    public static String url = "http://192.168.1.73/DIETAPP/";
    public static String videoUrl = "http://192.168.1.73/";


}
